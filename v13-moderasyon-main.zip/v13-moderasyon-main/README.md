# Ewing35 kanalında izin alınarak videosu çekilmiştir.

# Astpod#1411 & Cardea#2787

# Kurulum

1) Dosyaları indirin.
2) İndirdiğiniz dosyaları zip dosyasından çıkarıp bir dosya haline getirin.
3) Shift + Sağ Tık ile tıklayın. PowerShell şeklinde açın.
4) Açılan pencere içerisine "npm install" yazın ve "Enter" basın. Tamamlandıktan sonra pencereyi kapatın.
5) Kaynak kodu düzenleyiciniz ile **config.json** kısmını sunucunuza göre dizayn edin.
6) Dizayn ettiğiniz config.json dosyasını kaydedip kapatın.
7) Klasörün içinde bulunan `baslat.bat` uzantılı _batch_ dosyasını açın.
8) Tokenini girmiş olduğunuz bot sunucuda ekliyse çalışmaya başlayacaktır.

Sorun Olursa: Astpod#1411 & Cardea#2787

# Önemli

Proje bana aittir izinsiz paylaşılması yasaktır. Bazı hatalar vardır botta onları size bıraktım çözebilirsiniz. Hataları çözemezseniz Discord adresimden ulaşabilirsiniz. Daha iyisini yakında paylaşıcam bu sadece basit bir v13 Slash Commands moderasyon botudur içinde context menüde vardır. Stara basmayı unutmayın :))


# Sunucumuz

Discord Sunucumuz: discord.gg/serendia
