module.exports = {
    embedColor: "RANDOM",
    admins: ["Bot kurucusu ID"],
    serverId: "Sunucu ID",
    token: "Bot Tokeni",
    mongoURL: "Mongo URL'si",
    status: ["Serendia ❤️ Astpod", "Astpod ❤️ Serendia"],

    muteLimit: 10,
    banLimit: 5,
    vmuteLimit: 10,
    jailLimit: 6,

    tag: "Tagınız",
    tagsıztag: "•",

    booster: "Booster rolünüz",
    unregister: "Unregister rolünüz",
    erkek: "Erkek rolünüz",
    kız: "Kız rolünüz",

    muted: "Chat mute rolü",
    cezalı: "Cezalı rolü",
    şüpheli: "Şüpheli rolü",

    banHammer: ["Ban rolü", "2.rolü ekleyebilirsiniz"],
    registerHammer: ["Register rolü", "2.rolü ekleyebilirsiniz"],
    muteHammer: ["Mute rolü", "2.rolü ekleyebilirsiniz"],
    voiceMuteHammer: ["Voice Mute rolü", "2.rolü ekleyebilirsiniz"],
    jailHammer: ["Jail rolü", "2.rolü ekleyebilirsiniz"],
    transportHammer: ["Transport rolü", "2.rolü ekleyebilirsiniz"],

    banLog: "Ban log kanal ID",
    muteLog: "Mute log kanal ID",
    vmuteLog: "Voice Mute log kanal ID",
    jailLog: "Jail log kanal ID",
    botkomut: "bot komut kanal ID",


    ok: "Evet emoji ID",
    no: "Hayır emoji ID",
    okname: "Evet emoji ismi",
    noname: "Hayır emoji ismi"
}